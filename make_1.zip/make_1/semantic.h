#ifndef SEMANTIC_H
#define SEMANTIC_H
#include"bits/stdc++.h"
struct sematicError{
  std::vector<std::string> errors;
  sematicError();
  void add(std::string error);
  void display();
};

#endif
