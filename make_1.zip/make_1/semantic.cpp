#include"semantic.h"
using namespace std;
sematicError::sematicError(){

}

void sematicError::add(string error){
  for(string i:errors){
    if(i==error){
      return;
    }
  }
  errors.push_back(error);
}

void sematicError::display(){
  for(string error:errors){
    fprintf(stderr,"%s",error.c_str());
  }
}
