#ifndef NODE_H
#define NODE_H

#include"bits/stdc++.h"
#include"symtable.h"
using namespace std;
struct sym;

typedef struct node{
  int		int_val;
  float	float_val;
  string	type_val;
  string	name;
  int		tag;
  int		type;//0 nothing 1 end 2 relative 
  int 		dimension;
  sym*		id;
  int 		lineno;
  string	prefix;
  string	relativePrefix;
  vector<struct node*> children;
  node* 	parent;
  node(int tag,string name);
  node(int tag,string name,string type_val);
  void add(node* child);
  void analyze(int level);
  void push(initializer_list<node*> li);
  void output();
  void display(int dep);
}Node;
typedef union{
  struct node* ptr;
}YYLVAL;

#endif
