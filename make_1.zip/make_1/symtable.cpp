#include<bits/stdc++.h>
#include"symtable.h"
#include"semantic.h"
using namespace std;
extern string filename;
extern sematicError* error2;
//start function.
sym::sym(string name,int level,string type,char flag,int paramnum,int lineno):name(name),level(level),type(type),flag(flag),
paramnum(paramnum),strong(0),lineno(lineno),dimension(0){
  
}
//display a symbol;
void sym::display(int index){
  string array_type = type;
  //dimension
  for(int i=0;i<dimension;i++){
    array_type += "[]";
  }
  printf("%d\t%s\t%d\t%s\t%c",index,name.c_str(),level,array_type.c_str(),flag);
  if(paramnum>=0)printf("\t%d",paramnum);
  printf("\n");
}

symtable::symtable():index(0){

}

int symtable::check(sym* e){
  if(!symbols.empty()){
    //check the symbol e is OK or not.
    for(int i=symbols.size()-1;i>=0;i--){
      if(symbols[i]->level!=e->level){
        break;
      }
      if(symbols[i]->name!=e->name)continue;
      // the name is the same but the type is not OK.
      if(symbols[i]->dimension!=e->dimension||symbols[i]->type!=e->type){
        error2->add(filename+":"+to_string(e->lineno)+" ‘"+e->name+"’ redeclared as different kind of symbol\n");
        return 1;
      }
      //the type is the same and all isn't a temp value.
      if(symbols[i]->strong&&e->strong){
         error2->add(filename+":"+to_string(e->lineno)+" redefinition of ‘"+e->name+"’\n");
         return 1;
      }
    }
    return 0;
  }
  return 0;
}
//check the Exp...
int symtable::check(node* e,int lval){
  //param: lval means the node id a left value or not.(array type)
  // 0 : right value
  // 1 : left value
  // 2 : array value
  string name = e->name;
  int dimension = e->dimension;
  int Wrongcode = 0;
  string operator1;
  if(!symbols.empty()){
    for(int i=symbols.size()-1;i>=0;i--){
      //the name is correct but the type is float and the 
      if(symbols[i]->name != name) continue;
	    if(lval==2&&symbols[i]->type=="float"){
	      Wrongcode = 100;
        goto bad;
	    }
	    if(symbols[i]->dimension == dimension){
        //check a function type
	      if(symbols[i]->flag=='F'){
	        if(lval)
            //function type
            Wrongcode = 101;
	        else{
            //get the type of paramter
	          if(e->parent->name=="+"
	           ||e->parent->name=="-"
	           ||e->parent->name=="*"
	           ||e->parent->name=="/"
	           ||e->parent->name=="%"
	           ||e->parent->name==">"
	           ||e->parent->name=="<"
	           ||e->parent->name=="=="
	           ||e->parent->name=="!="
	           ||e->parent->name==">="
	           ||e->parent->name=="<="
	           ||e->parent->name=="&&"
	           ||e->parent->name=="||")
            {
	            operator1=" to binary operator "+e->parent->name;
	          }
            else operator1="";
            Wrongcode = 102;
	        }
	        goto bad;
	      }
        //not a function type
        else
	        return 0;
	    }
      //dimension is not correct.
      else{
        //left value but not a array
	      if(lval==1){
          Wrongcode = 200;
	        goto bad;
	      }
        //right value
        else if(symbols[i]->dimension == 0){
          Wrongcode = 202;
	        goto bad;
	      }
        //if not correct...
	      goto bad;
	    }
    }
    //not found.
    Wrongcode = 404;
    goto bad;
  }
  //empty means not found.
  Wrongcode = 404;
  goto bad;
  bad:
    switch(Wrongcode){
      case 100:
        error2->add(filename+":"+to_string(e->lineno)+" array subscript is not an integer\n");
        break;
      case 200:
        error2->add(filename+":"+to_string(e->lineno)+" assignment to expression with array type\n");
        break;
      case 202:
        error2->add(filename+":"+to_string(e->lineno)+" subscripted value is not an array\n");
        break;
      case 102:
        error2->add(filename+":"+to_string(e->lineno)+" invalid operands"+operator1+"\n");
        break;
      case 101:
        error2->add(filename+":"+to_string(e->lineno)+" lvalue required as left operand of assignment\n");
        break;
      case 404:
        error2->add(filename+":"+to_string(e->lineno)+" ‘"+e->name+"’ undeclared\n");
        break;
    }
    return 1;
}

void symtable::checkInt(node* exp){
  if(exp->name=="float"){
    error2->add(filename+":"+to_string(exp->lineno)+" array subscript is not an integer\n");
  }else if(exp->type_val=="ID"){
    check(exp,2);
  }
  for(node* i:exp->children){
     checkInt(i);
  }
}

void symtable::checkFunc(node *func){
  string name=func->name;
  int Wrongcode = 0;
  int i;
  if(!symbols.empty()){
    for(i=symbols.size()-1;i>=0;i--){
	    if(symbols[i]->name+"( )" != name)continue;
	    if(symbols[i]->flag!='F'){
        Wrongcode = 106;
	      goto bad;
	    }
      else if(symbols[i]->paramnum>func->children.size()){
	      Wrongcode = 107;
	      goto bad;
	    }
      else if(symbols[i]->paramnum<func->children.size()){
        Wrongcode = 108;
	      goto bad;
	    }
      else{
	      return;
	    }
    }
    return;
  }
  bad:
  switch(Wrongcode){
    case 106:
      error2->add(filename+":"+to_string(func->lineno)+" ‘"+symbols[i]->name+"’ is not a function\n");
      break;
    case 107:
      error2->add(filename+":"+to_string(func->lineno)+" too few arguments to function ‘"+symbols[i]->name+"’\n");
      break;
    case 108:
      error2->add(filename+":"+to_string(func->lineno)+" too many arguments to function ‘"+symbols[i]->name+"’\n");
      break;
  }
  return;
}

void symtable::checkBlock(node *e){
  string name = e->name;
  int ret = e->children.size()>0;
  for(node *i=e;i;i=i->parent){
    if(name=="continue"||name=="break"){
      if(i->name=="for"||i->name=="while"){
        return;
      }
    }else if(name=="return"){
      if(i->name=="FuncDef"){
        if(i->children[0]->children[0]->name=="void"&&ret){
          error2->add(filename+":"+to_string(e->lineno)+" ‘return’ with a value, in function returning void\n");
          return;
        }
        else if(i->children[0]->children[0]->name!="void"&&!ret){
          error2->add(filename+":"+to_string(e->lineno)+" ‘return’ without value, in function returning "+i->children[0]->children[0]->name+"\n");
          return;
        }else 
          return;
      }
    }
  }
  error2->add(filename+":"+to_string(e->lineno)+" "+e->name+" statement not within a loop\n");
  return;
}



void symtable::add(sym* e){
  if(!check(e)){
    symbols.push_back(e);
    index++;
  }
}
// add a lot of..
void symtable::addlist(node* list){
  for(node* i:list->children){
    if(i->id){
      if(!check(i->id)){
        symbols.push_back(i->id);
        index++;
      }
    }
    if(!i->children.empty()){
      for(node* j:i->children){
        if(j!=i->children[0]){
          add(j);
        }
      }
    }
  }
}

//pop the level
void symtable::pop(int level){
  int popflag=0;
  while(!symbols.empty()&&symbols.back()->level==level){
    popflag=1;
    index--;
    symbols.pop_back();
  }
}

void symtable::add(node* tree){
  if(tree->id){
        add(tree->id);
  }
  if(tree->name=="FuncDef"){
       for(node* i:tree->children){
         if(i!=tree->children[0]){
           add(i);
         }
       }
       return;
  }
  if(tree->name=="VarDecl"||tree->name=="ConstDecl"){
    addlist(tree);
    return;
  }
  if(tree->name=="="){
    check(tree->children[0],1);
    add(tree->children[1]);
    return;
  }
  if(tree->type_val=="ID"){
    check(tree,0);
  }
  if(tree->name=="[]"){
    if(!tree->children.empty())
    	checkInt(tree->children[0]);
  }
  if(tree->name=="return"||tree->name=="break"||tree->name=="continue"){
    checkBlock(tree);
  }
  if(tree->type_val=="Func"){
    checkFunc(tree);
  }
  for(node* i:tree->children){
    add(i);
  }
  if(tree->name=="Block"){
    pop(tree->int_val);
  }
}

void symtable::display(){
  printf("----------------symbol table-----------------------\n");
  printf("Index\tName\tLevel\tType\tFlag\tParam_num\n");
  printf("---------------------------------------------------\n");
  for(int i=0;i<index;i++){
    symbols[i]->display(i);
  }
  printf("---------------------------------------------------\n");
}
