#ifndef SYMTABLE_H
#define SYMTABLE_H

#include"def.h"
using namespace std;
struct node;
struct sym {       //这里只列出了一个符号表项的部分属性，没考虑属性间的互斥  
    string name;   //变量或函数名  
    int level;        //层号  
    string type;         //变量类型或函数返回值类型  
    int dimension;
    char flag;       //符号标记，函数：'F'  变量：'V'   参数：'P'  临时变量：'T' 
    int  paramnum;  //对函数适用，记录形式参数个数  
    int lineno;
    int  strong;
    node* val;
    string alias;   //别名，为解决嵌套层次使用   
    char offset;      //外部变量和局部变量在其静态数据区或活动记录中的偏移量，  
//或记录函数活动记录大小，目标代码生成时使用  
    //函数入口等实验可能会用到的属性...
     sym(string name,int level,string type,char flag,int paramnum,int lineno);
     void display(int index);
    };  
//符号表  
struct symtable{  
    vector<sym*> symbols;  
    int index; 
    symtable(); 
    int check(sym* e);
    int check(node* e,int lval);
    void checkInt(node* exp);
    void checkFunc(node *func);
    void checkBlock(node *e);
    void add(sym* e);
    void addlist(node* list);
    void pop(int level);
    void add(node* tree);
    void display();
    };

#endif
