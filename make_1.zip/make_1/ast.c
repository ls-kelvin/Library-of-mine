#include"bits/stdc++.h"
#include"def.h"
#include"symtable.h"
using namespace std;
extern int yylineno;
// start function
node::node(int tag,string name):tag(tag),type(0),name(name),id(NULL),lineno(yylineno),dimension(0),parent(NULL){
 type_val="$$";
}

node::node(int tag,string name,string type_val):tag(tag),type(0),name(name),type_val(type_val),id(NULL),lineno(yylineno),dimension(0){
 
}
//add a child
void node::add(node* child){
  // noting to store
  if(child->tag!=-1){
    child->parent = this;
  	children.push_back(child);
  }
  //there's something to store.
  else{
  	for(Node* new_child:child->children){
      child->parent = this;
  		children.push_back(new_child);
  	}
  	if(child->name!="CompUnit")child->~Node();
  }
}

void node::push(initializer_list<node*> li){
  for(Node* i:li){
  	add(i);
  }
}
//0 name 1 int 2 float 3 type/id 4 list 5 tree
void node::output(){
  string pre = prefix!= "" ? prefix+"--":"";
  if(type==2||type==3)pre=relativePrefix+"--";
  switch(tag){
    //noting
    case-1:printf("%s%s\n",pre.c_str(),name.c_str());break;
    case 0:printf("%s%s\n",pre.c_str(),name.c_str());break;
    //int
    case 1:printf("%s%s %d\n",pre.c_str(),name.c_str(),int_val);break;
    //float
    case 2:printf("%s%s %f\n",pre.c_str(),name.c_str(),float_val);break;
    //id
    case 3:printf("%s%s %s\n",pre.c_str(),name.c_str(),type_val.c_str());break;
    //Definition value
    case 4:printf("%s%s",pre.c_str(),name.c_str());
           for(Node* i:children){
           	printf(" %s",i->name.c_str());
           }
           printf("\n");break;
    //No children end.
    case 5:printf("%s%s",pre.c_str(),name.c_str());
           if(children.size()==0)printf("\n");break;
  }
}

void node::analyze(int level){
  string pass="";
  int cases = 0;
  int dimension = 0;
  //analyse
  //make a pass string..
  if(name=="ConstDecl"){
    cases = 1;
  }else if(name=="VarDecl"){
    cases = 2;
  }else if(name=="ConstDef"||name=="VarDef"){
    cases = 3;
  }else if(name=="Param"){
    cases = 4;
  }else if(name=="Block"){
    cases = 5;
  }
  switch(cases){
    case 1:
    //Const Declaration
      pass="const "+children[0]->name;
      break;
    case 2:
    //Declaration
      pass=children[0]->name;
      break;
    case 3:
    // Definition.
      //handle array
      dimension=0;
      for(node* i:children){
        if(i->name=="[]"){
          dimension++;
        }
      }
      // add a new symbols.
      id=new sym(children[0]->name,level,type_val,'V',-1,children[0]->lineno);
      id->dimension = dimension;
      if(children.back()->name=="InitVal"||children.back()->name=="ConstInitVal"){
        id->strong = 1;
        id->val = children[2];
      }
      break;
    case 4:
    //Parameter
      dimension = 0;
      for(node* i:children){
        if(i->name=="[]"){
          dimension++;
        }
      }
      //at the same time add a new symbol;
      id=new sym(children[1]->name,level+1,children[0]->name,'P',-1,children[1]->lineno);
      id->dimension = dimension;
      id->strong = 1;
      break;
    case 5:
    // a new block, level + 1
      level++;
      int_val=level;
      break;
  }
  // all children
  for(node* i:children){
    // send the inheritent value
    if((i->name=="VarDef"||i->name=="ConstDef")&&pass!=""){
	    i->type_val=pass;
    }
    i->analyze(level);
  }
  // a new functiom.
  if(name=="FuncDef"){
    string funcType=children[0]->children[0]->name+"(";
    int paramnum=0;
    //handle the paramters.
    if(children[1]->name=="FuncFParams")
    //for the all node in paramter.
      for(node*i:children[1]->children){
          if(i->id){
           if(i!=children[1]->children.front())funcType+=",";
	        funcType+=i->id->type;
	        paramnum++;
	      }
      }
    if(paramnum==0)funcType+="void";
    funcType+=")";
    //add a new symbol
    id=new sym(children[0]->children[1]->name,level,funcType,'F',paramnum,children[0]->children[1]->lineno);
    //strong means no temp value.
    id->strong = 1;
    id->val = children[2];
  }else if(name=="Block"){
    level--;
  }
}

void node::display(int dep){
  //display handle the css.
  if(dep == 0) prefix = "";
  string pre = prefix;
  if(type==1||type==3) pre[pre.size()-1]=' ';
  
  if(dep == 0) pre ="|";
  else pre += "  |";
  if(tag==5){
    pre=prefix;
    if(type==1||type==3) pre[pre.size()-1]=' ';
    for(int i=0;i<name.size();i++)pre+=" ";
    if(children.size()==1)pre+=" |";
    else pre+="   |";
  }
  //print the line here.
  output();
  if(tag == 4)return;
  // if there is a children handle the prefix and display it.
  for(node* i:children){
    i->prefix=pre;
    if(i==children.back()){
    	i->type+=1;
    	i->prefix[i->prefix.size()-1]='`';
    }
    if(tag==5&&i==children.front()){
        i->type+=2;
        i->relativePrefix=children.size()==1?"":"--";
    }
    i->display(dep+1);
  }
}
